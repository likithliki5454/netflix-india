export const API_OPTIONS={
    method: 'GET',
    headers: {
      accept: 'application/json',
      Authorization: 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiJlYWQ0MDMyNDM2NDg4M2Y5MTM5YzZlZjYyNGYxMGE1NCIsInN1YiI6IjY1YzcxNWRmZTRiNTc2MDE3ZDE0NjY3YyIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.Wx8AdNiSy2LDs7FLIqaLnhTfDQ7zs9zjg77h1LIzvAE'
    }
  };

  export const IMG_CDN_URL="https://image.tmdb.org/t/p/w500"